import logo from "./logo.svg";
import "./App.css";
import Navbar from "./components/navbar/nav-bar";
import NavigationStack from "./navigation/navigation-stack";

function App() {
  return <NavigationStack />;
}

export default App;
