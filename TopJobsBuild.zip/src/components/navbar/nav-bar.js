import React, { Children } from "react";
import { Link } from "react-router-dom";

function Navbar() {
  const styleObject = {
    style: {
      textDecoration: "none",
      color: "#191970",

    },
  };

  return (
    <>
      <nav className="navbar navbar-expand-lg bg-secondary navbar-scroll  shadow-0 border-bottom border-dark">
        <div className="container">
          <Link to="/" >
      
        <img 
      src="https://images.unsplash.com/photo-1611605698323-b1e99cfd37ea?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTJ8fGljb258ZW58MHx8MHx8&auto=format&fit=crop&w=800&q=60"
      alt="new"
      style={{height:50,width:50,marginRight:10}}
      />
          </Link>


          <Link to="/" style={styleObject.style} className="linkTag">
            {" "}
          
            <h3>TopJobs</h3>
          </Link>
          <div></div>

          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav ms-auto">
              <li className="nav-item"></li>
              <li className="nav-item">
              <Link to="/" className="my-link"  style={styleObject.style}>
                  {" "}
                
                        <button type="button" className="btn btn-dark ms-3">Home</button>
                </Link>
              </li>
              <li className="nav-item">
              <Link to="/contact" className="my-link"  style={styleObject.style}>
                  {" "}
                
                        <button type="button" className="btn btn-dark ms-3">Contact us</button>
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/jobs" className="my-link"  style={styleObject.style}>
                  {" "}
                
                        <button type="button" className="btn btn-dark ms-3">Jobs</button>
                </Link>
              </li>
             
            </ul>
          </div>
        </div>
      </nav>
    </>
  );
}

export default Navbar;
