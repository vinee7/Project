import React from 'react';

function Footer() {
  const contactData = {
    address: "123 Park Avenue C, AK Marg, Delhi, India",
    phone: [
      "(91) 987 654 3210",
      "(91) 987 654 3211"
    ],
    email: "contact@topjobs.com"
  };

  const styles = {
    container: {
      backgroundColor: '#333',
      color: '#fff',
      padding: '1rem',
      textAlign: 'center',
      fontSize: '0.9rem'
    },
    address: {
      marginBottom: '0.5rem'
    },
    phone: {
      marginBottom: '0.5rem'
    },
    email: {
      fontWeight: 'bold'
    }
  };

  return (
    <footer style={styles.container}>
      <div style={styles.address}>{contactData.address}</div>
      <div style={styles.phone}>
        {contactData.phone.map((phoneNumber, index) => (
          <span key={index}>
            {phoneNumber}
            {index !== contactData.phone.length - 1 && ', '}
          </span>
        ))}
      </div>
      <div style={styles.email}>{contactData.email}</div>
    </footer>
  );
}

export default Footer;
