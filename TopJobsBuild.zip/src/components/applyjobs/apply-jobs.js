import React from 'react';
import { useParams } from 'react-router-dom';

function ApplyJob() {
  const { jobId } = useParams();


  console.log(jobId)

  return (
    <div>
      <h1>Apply Job</h1>
      {/* Add a form or other content for applying to the job */}
    </div>
  );
}

export default ApplyJob;



