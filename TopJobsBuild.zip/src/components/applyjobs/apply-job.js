import React, { useState } from "react";
import Navbar from "../navbar/nav-bar";
import './styles.css'


const ApplyJobForm = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [Address,setAddress]=useState("")
  const [message, setMessage] = useState("");
  const [nameError, setNameError] = useState("");
  const [emailError, setEmailError] = useState("");
   const [phoneError, setPhoneError] = useState("");
   const[addresserror,setAddressError]=useState("")
   const [messageError, setMessageError] = useState("");
   const [successMessage, setSuccessMessage] = useState("");
  // const [errorMessage, setErrorMessage] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    //Name validation
    const nameRegex = /^[a-zA-Z\s]*$/;
    if (!name) {
      setNameError('Name should not be blank');
    } else if (!nameRegex.test(name)) {
      setNameError('Name must only contain letters and whitespace.');
    } else {
      setNameError('');
    }
    //Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
      if (!emailRegex.test(email)) {
        // email is invalid, so show an error message
        setEmailError('Please enter a valid email address.');
      } else {
        // email is valid, so clear the error message
        setEmailError('');
      }
    
    //phonenumber validation
    const phoneNumberRegex = /^[0-9]{10}$/;
    if (!phoneNumberRegex.test(phoneNumber)) {
      setPhoneError("Please enter a valid 10 digit mobile number");
    } else {
      setPhoneError("");
    }
    //Address validation
    if (Address.length < 10) {
      setAddressError("Address should be at least 10 characters long.");
    } else if (Address.length > 50) {
      setAddressError("Address should not be more than 50 characters long.");
    } else {
      setAddressError("");
    }
    //message validation
    if (message.length < 10) {
      setMessageError("Message should be at least 10 characters long.");
    } else if (message.length > 150) {
      setMessageError("Message should not be more than 150 characters long.");
    } else {
      setMessageError("");
    }
  //success message validation
    if (nameRegex.test(name) && email.trim() !== '' && emailRegex.test(email) && phoneNumberRegex.test(phoneNumber) && Address.length >= 10 && Address.length <= 150 && message.length >= 10 && message.length <= 150)
   {
      setSuccessMessage('Your message has been successfully submitted!');
      
      const data={
        name,email,phoneNumber,Address,message
      }

      const jsonData=JSON.stringify(data)
console.log(jsonData,"json data")
//set input fields empty after submitting successfully

      // Api call 
      setName("")
      setEmail("")
      setMessage("")
      setPhoneNumber("")
      setAddress("")
    } else {
      setSuccessMessage('');
    }
  };
  
  return (
    <>
    <Navbar/>

    <div>
      <div >
        <form onSubmit={handleSubmit} >
          <h2>Job applying for:</h2>
          <input
            type="text"
            placeholder="Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            
            
          /><br></br>
           {nameError && <p style={{color:"red"}}>{nameError}</p>}
          <input
            type="text"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
           
          /><br></br>
          {emailError && <p style={{color:"red"}}>{emailError}</p>}
          <input
            type="tel"
            placeholder="Phone Number"
            value={phoneNumber}
            onChange={(e) => setPhoneNumber(e.target.value)}
            
          /><br></br>
            {phoneError &&<p style={{color:"red"}}>{phoneError}</p>}
            <input
            type="text"
            placeholder="Address"
            value={Address}
            onChange={(e) => setAddress(e.target.value)}
            
          /><br></br>
           {addresserror && <p style={{color:"red"}}>{addresserror}</p>}
          <textarea 
            placeholder="Message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            
          /><br></br>
          {messageError && <p style={{color:"red"}}>{messageError}</p>}
          <button type="submit" >Submit</button>
          {successMessage && <p style={{ color: 'green' }}>{successMessage}</p>}

        </form>
      </div>
       
    </div>

    </>
  );
};

export default ApplyJobForm;