import React, { useState } from "react";
import ContactImage from '../../assets/images/contactUs.jpg'
import Footer from "../footer/Footer";
import Navbar from "../navbar/nav-bar";


const ContactScreen = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [message, setMessage] = useState("");
  const [nameError, setNameError] = useState("");
  const [emailError, setEmailError] = useState("");
   const [phoneError, setPhoneError] = useState("");
   const [messageError, setMessageError] = useState("");
   const [successMessage, setSuccessMessage] = useState("");
  // const [errorMessage, setErrorMessage] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    //Name validation
    const nameRegex = /^[a-zA-Z\s]*$/;
    if (!name) {
      setNameError('Name should not be blank');
    } else if (!nameRegex.test(name)) {
      setNameError('Name must only contain letters and whitespace.');
    } else {
      setNameError('');
    }
    //Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
      if (!emailRegex.test(email)) {
        // email is invalid, so show an error message
        setEmailError('Please enter a valid email address.');
      } else {
        // email is valid, so clear the error message
        setEmailError('');
      }
    
    //phonenumber validation
    const phoneNumberRegex = /^[0-9]{10}$/;
    if (!phoneNumberRegex.test(phoneNumber)) {
      setPhoneError("Please enter a valid 10 digit mobile number");
    } else {
      setPhoneError("");
    }
    //message validation
    if (message.length < 10) {
      setMessageError("Message should be at least 10 characters long.");
    } else if (message.length > 150) {
      setMessageError("Message should not be more than 150 characters long.");
    } else {
      setMessageError("");
    }
  //success message validation
    if (nameRegex.test(name) && email.trim() !== '' && emailRegex.test(email) && phoneNumberRegex.test(phoneNumber) && message.length >= 10 && message.length <= 150)
   {
      setSuccessMessage('Your message has been successfully submitted!');
      
      const data={
        name,email,phoneNumber,message
      }

      const jsonData=JSON.stringify(data)
console.log(jsonData,"json data")
//set input fields empty after submitting successfully

      // Api call 



      setName("")
      setEmail("")
      setMessage("")
      setPhoneNumber("")
    } else {
      setSuccessMessage('');
    }
  };
  
  return (
    <>
    <Navbar/>

    <div
      style={{
        display: "flex",
        // border: "solid 1px black",
        padding: "10px",
        margin: "1% 1%",
        minHeight: "100vh"
      }}
    >
      <div style={{ width: "50%", display: "flex", justifyContent: "center", alignItems: "center" }}>
        <form onSubmit={handleSubmit} style={{ width: "80%", display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
          <h2 style={{ color: "red", textAlign: "middle",fontWeight: "normal" }}>Get In Touch</h2>
          <input
            type="text"
            placeholder="Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            style={{ width: "100%", height: "40px", marginBottom: "15px" ,
             }}
          />
           {nameError && <p style={{color:"red"}}>{nameError}</p>}
          <input
            type="text"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={{ width: "100%", height: "40px", marginBottom: "15px" }}
          />
          {emailError && <p style={{color:"red"}}>{emailError}</p>}
          <input
            type="tel"
            placeholder="Phone Number"
            value={phoneNumber}
            onChange={(e) => setPhoneNumber(e.target.value)}
            style={{ width: "100%", height: "40px", marginBottom: "15px" }}
          />
            {phoneError &&<p style={{color:"red"}}>{phoneError}</p>}
          <textarea
            placeholder="Message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            style={{ width: "100%", height: "120px", marginBottom: "15px" }}
          />
          {messageError && <p style={{color:"red"}}>{messageError}</p>}
          
          
          <button type="submit"  style={{ backgroundColor: "red", color: "white",width:"20%" }}>Submit</button>
          {successMessage && <p style={{ color: 'green' }}>{successMessage}</p>}

        </form>
      </div>
      <div style={{ width: "50%", display: "flex", justifyContent: "center", alignItems: "center" }}>
      <img src={ContactImage} alt="placeholder" style={{ maxWidth: "80%", maxHeight: "100%" }} />
        </div>
       
    </div>
    <Footer/>
  
    </>
  );
};

export default ContactScreen;