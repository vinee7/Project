import React, { useEffect, useState } from 'react';
import './styles.css'; // Import the CSS file

import c1 from "../../assets/images/1.jpg"
import c2 from "../../assets/images/2.jpg"
import c3 from "../../assets/images/3.jpg"


const Carousel = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const images = [
  c1,c2,c3
  
  ];

  const handlePrevClick = () => {
    setActiveIndex((activeIndex - 1 + images.length) % images.length);
  };

  const handleNextClick = () => {
    setActiveIndex((activeIndex + 1) % images.length);
  };
  useEffect(() => {
    const intervalId = setInterval(() => {
      setActiveIndex((activeIndex + 1) % images.length);
    }, 2000);
    return () => clearInterval(intervalId);
  }, [activeIndex, images.length]);

  return (
    <div className="carousel">
      <img
        className="carousel-image"
        src={images[activeIndex]}
        alt={`Image ${activeIndex}`}
      />
      <div className="controls">
        <button className="prev" onClick={handlePrevClick}>
          &#10094;
        </button>
        <button className="next" onClick={handleNextClick}>
          &#10095;
        </button>
      </div>
    </div>
  );
};

export default Carousel;
