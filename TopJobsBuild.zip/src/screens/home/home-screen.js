import React from 'react'

import Navbar from '../../components/navbar/nav-bar'
import "react-responsive-carousel/lib/styles/carousel.min.css";
import Carousel from '../../components/corousel/corousel';
import { Link } from 'react-router-dom';


function HomeScreen() {
  return (
    <>
    <Navbar/>
    <Carousel/>
    <div className="header" style={{marginTop:20}} >
        <Link to="/jobs">
          <button className="button">Jobs</button>
        </Link>
        <Link to="/contact">
          <button className="button">ContactUs</button>
        </Link>
        <button className="button coming-soon">ComingSoon</button>
      </div>


  
  </>
  )
}

export default HomeScreen