import React from 'react';
import { Link } from 'react-router-dom';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import { GeoAlt, BriefcaseFill, CurrencyDollar } from 'react-bootstrap-icons';
import './styles.css'; // import custom CSS file
import Navbar from '../../components/navbar/nav-bar';

const jobs = [
  {
    id: 1,
    role: 'Software Engineer',
    company: 'Example Inc.',
    experience: '3+ years',
    salary: '$100,000 - $120,000',
    location: 'San Francisco, CA',
  },
  {
    id: 2,
    role: 'Marketing Manager',
    company: 'ABC Corp.',
    experience: '5+ years',
    salary: '$80,000 - $100,000',
    location: 'New York, NY',
  },
  {
    id: 3,
    role: 'React developer',
    company: 'ABC Corp.',
    experience: '5+ years',
    salary: '$80,000 - $100,000',
    location: 'New York, NY',
  }, {
    id: 4,
    role: 'React-Native developer',
    company: 'ABC Corp.',
    experience: '5+ years',
    salary: '$80,000 - $100,000',
    location: 'New York, NY',
  },
  {
    id: 5,
    role: 'Angular developer',
    company: 'ABC Corp.',
    experience: '5+ years',
    salary: '$80,000 - $100,000',
    location: 'New York, NY',
  }, {
    id: 6,
    role: 'Dot-js developer',
    company: 'ABC Corp.',
    experience: '5+ years',
    salary: '$80,000 - $100,000',
    location: 'New York, NY',
  },
  // more job objects can be added here
];

function JobList() {
  return (
    <>
    <Navbar/>
   
    <Container className="job-list">
      <h1>Job Listings</h1>
      <Row>
        {jobs.map(job => (
          <Col md={6} key={job.id}>
            <Card className="mb-4">
              <Card.Body>
                <Card.Title>{job.role}</Card.Title>
                <Card.Subtitle className="mb-2 text-muted">{job.company}</Card.Subtitle>
                <Card.Text>
                  <GeoAlt /> {job.location}
                  <br />
                  <BriefcaseFill /> {job.experience}
                  <br />
                  <CurrencyDollar /> {job.salary}
                </Card.Text>
                <Link to={`apply/${job.id}`}>
                  <Button variant="primary">Apply Job</Button>
                </Link>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
    </Container>
    </>
  );
}

export default JobList;
