import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import React, { useState } from "react";
import "./styles.css";

import { Outlet, Link } from "react-router-dom";
import Navbar from "../components/navbar/nav-bar";
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from "react-responsive-carousel";
import corosel1 from "../assets/images/1.jpg";
import corosel2 from "../assets/images/2.jpg";
import corosel3 from "../assets/images/3.jpg";
// import ApplyForm from "../components/contact/contact-page"
import "./styles.css";
import JobList from "../screens/jobs/job-screen";
import ApplyJob from "../components/applyjobs/apply-jobs";
import HomeScreen from "../screens/home/home-screen";
import ContactScreen from "../components/contact/contact-page";
import ApplyJobForm from "../components/applyjobs/apply-job";

export default function NavigationStack() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<HomeScreen />} />

        <Route path="jobs" element={<JobList />} />
        <Route path="contact" element={<ContactScreen/>} />


        {/* dynamic routing */}
        <Route 
         path='/jobs/apply/:id' element={<ApplyJobForm/>} />
        
      </Routes>
    </BrowserRouter>
  );
}



